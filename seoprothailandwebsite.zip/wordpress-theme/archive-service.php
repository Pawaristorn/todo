<?php get_header(); ?>

<section class="page-hero pt-36 pb-20 lg:pt-44 lg:pb-28 text-white relative z-10">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
    <div class="reveal">
      <span class="inline-flex items-center gap-2 px-4 py-1.5 bg-white/10 border border-white/20 rounded-full text-sm font-semibold mb-6 backdrop-blur-sm">
        <i class="fas fa-cogs text-gold-400 text-xs"></i>บริการ
      </span>
      <h1 class="text-4xl lg:text-6xl font-bold mb-4 leading-tight">
        บริการรับทำ<span class="font-display italic text-gold-400"> SEO ครบวงจร</span>
      </h1>
      <p class="text-lg text-white/75 max-w-2xl mx-auto">ครอบคลุมทุกมิติ SEO ด้วยทีมผู้เชี่ยวชาญกว่า 8 ปี</p>
    </div>
  </div>
</section>

<section class="py-20 bg-white">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <?php if (have_posts()): ?>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      <?php while (have_posts()): the_post(); ?>
      <article <?php post_class('luxury-card glass-card rounded-2xl p-7 reveal'); ?>>
        <div class="w-12 h-12 rounded-xl bg-gradient-to-br from-primary-500 to-primary-700 flex items-center justify-center text-white text-lg mb-5 shadow-lg shadow-primary-500/25">
          <?php $icon = get_post_meta(get_the_ID(), 'service_icon', true); ?>
          <i class="<?php echo $icon ?: 'fas fa-cog'; ?>"></i>
        </div>
        <h2 class="font-bold text-slate-900 mb-3"><a href="<?php the_permalink(); ?>" class="hover:text-primary-600 transition-colors"><?php the_title(); ?></a></h2>
        <p class="text-slate-500 text-sm mb-4 leading-relaxed"><?php the_excerpt(); ?></p>
        <a href="<?php the_permalink(); ?>" class="inline-flex items-center gap-1 text-primary-600 text-sm font-semibold hover:gap-2 transition-all">อ่านเพิ่มเติม <i class="fas fa-arrow-right text-xs"></i></a>
      </article>
      <?php endwhile; ?>
    </div>
    <?php else: ?>
    <div class="text-center py-16 text-slate-400">
      <i class="fas fa-cogs text-4xl mb-4 opacity-30"></i>
      <p>ยังไม่มีบริการ — เพิ่มบริการใน WordPress Admin → Services</p>
    </div>
    <?php endif; ?>
  </div>
</section>

<section class="cta-section py-20 text-white">
  <div class="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center reveal">
    <h2 class="text-3xl lg:text-4xl font-bold mb-4">สนใจบริการของเรา?</h2>
    <p class="text-white/70 mb-7">ติดต่อเราเพื่อรับข้อเสนอที่ออกแบบเฉพาะสำหรับธุรกิจคุณ</p>
    <a href="<?php echo get_permalink(get_page_by_path('contact')); ?>" class="inline-flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-gold-500 to-gold-600 text-white font-bold rounded-2xl hover:shadow-xl hover:shadow-gold-500/30 hover:-translate-y-1 transition-all">
      <i class="fas fa-paper-plane"></i>ขอคำปรึกษาฟรี
    </a>
  </div>
</section>

<?php get_footer(); ?>
