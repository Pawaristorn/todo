<?php get_header(); ?>

<?php while (have_posts()): the_post(); ?>

<section class="page-hero pt-36 pb-20 lg:pt-44 lg:pb-28 text-white relative z-10">
  <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
    <div class="reveal">
      <div class="flex items-center justify-center gap-2 text-white/60 text-sm mb-4">
        <a href="<?php echo home_url('/'); ?>" class="hover:text-gold-400 transition-colors">หน้าแรก</a>
        <i class="fas fa-chevron-right text-xs"></i>
        <a href="<?php echo get_permalink(get_page_by_path('blog')); ?>" class="hover:text-gold-400 transition-colors">บทความ</a>
        <i class="fas fa-chevron-right text-xs"></i>
        <span class="text-white/40 line-clamp-1"><?php the_title(); ?></span>
      </div>
      <h1 class="text-3xl lg:text-5xl font-bold mb-4 leading-tight"><?php the_title(); ?></h1>
      <div class="flex items-center justify-center gap-4 text-white/60 text-sm">
        <span><i class="fas fa-calendar mr-1"></i><?php echo get_the_date('d M Y'); ?></span>
        <span><i class="fas fa-user mr-1"></i><?php the_author(); ?></span>
        <span><i class="fas fa-clock mr-1"></i><?php echo ceil(str_word_count(get_the_content()) / 200); ?> นาที</span>
      </div>
    </div>
  </div>
</section>

<section class="py-20 bg-white">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-10">
      <article class="lg:col-span-2">
        <?php if (has_post_thumbnail()): ?>
        <div class="rounded-3xl overflow-hidden mb-8 shadow-xl">
          <?php the_post_thumbnail('full', ['class' => 'w-full h-72 object-cover']); ?>
        </div>
        <?php endif; ?>
        <div class="prose prose-slate prose-lg max-w-none glass-card rounded-3xl p-8 lg:p-10">
          <?php the_content(); ?>
        </div>
        <div class="mt-8 flex items-center gap-3">
          <span class="text-sm font-semibold text-slate-600">แท็ก:</span>
          <?php the_tags('<span class="inline-flex flex-wrap gap-2">', '', '</span>'); ?>
        </div>
        <!-- Author Box -->
        <div class="glass-card rounded-2xl p-6 mt-8 flex items-start gap-4">
          <?php echo get_avatar(get_the_author_meta('ID'), 64, '', '', ['class' => 'rounded-xl flex-shrink-0']); ?>
          <div>
            <p class="font-bold text-slate-900"><?php the_author(); ?></p>
            <p class="text-slate-500 text-sm mt-1"><?php the_author_meta('description'); ?></p>
          </div>
        </div>
      </article>

      <!-- Sidebar -->
      <aside class="space-y-6">
        <div class="glass-card rounded-2xl p-6">
          <h3 class="font-bold text-slate-900 mb-4 text-sm uppercase tracking-wider">บทความที่เกี่ยวข้อง</h3>
          <?php
          $related = new WP_Query(['post_type' => 'post', 'posts_per_page' => 4, 'post__not_in' => [get_the_ID()], 'category__in' => wp_get_post_categories(get_the_ID())]);
          while ($related->have_posts()): $related->the_post(); ?>
          <a href="<?php the_permalink(); ?>" class="flex items-start gap-3 py-3 border-b border-slate-100 last:border-0 hover:text-primary-600 transition-colors group">
            <?php if (has_post_thumbnail()): ?>
            <div class="w-14 h-14 rounded-xl overflow-hidden flex-shrink-0"><?php the_post_thumbnail('thumbnail', ['class' => 'w-full h-full object-cover group-hover:scale-105 transition-transform']); ?></div>
            <?php endif; ?>
            <div><p class="text-sm font-medium leading-tight"><?php the_title(); ?></p><p class="text-xs text-slate-400 mt-1"><?php echo get_the_date('d M Y'); ?></p></div>
          </a>
          <?php endwhile; wp_reset_postdata(); ?>
        </div>
        <div class="cta-section rounded-2xl p-6 text-white text-center">
          <i class="fas fa-rocket text-gold-400 text-2xl mb-3"></i>
          <h3 class="font-bold mb-2 text-sm">ต้องการติด Google หน้าแรก?</h3>
          <p class="text-white/70 text-xs mb-4">รับคำปรึกษาฟรีจากผู้เชี่ยวชาญของเรา</p>
          <a href="<?php echo get_permalink(get_page_by_path('contact')); ?>" class="block py-2.5 bg-gradient-to-r from-gold-500 to-gold-600 text-white font-semibold rounded-xl text-sm">ขอคำปรึกษาฟรี</a>
        </div>
      </aside>
    </div>
  </div>
</section>

<?php endwhile; ?>

<?php get_footer(); ?>
