<?php get_header(); ?>

<!-- Hero Section -->
<section class="hero-bg min-h-screen flex items-center pt-20 pb-16 relative overflow-hidden">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
      <div class="reveal">
        <div class="inline-flex items-center gap-2 px-4 py-2 luxury-badge rounded-full text-xs font-semibold text-primary-700 mb-8">
          <i class="fas fa-award text-gold-500"></i>
          <span>อันดับ 1 ด้าน SEO ในประเทศไทย</span>
          <span class="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
        </div>
        <h1 class="text-5xl lg:text-7xl font-bold leading-tight text-slate-900 mb-6">
          พาธุรกิจคุณ<br>
          สู่<span class="font-display italic gradient-text">หน้าแรก Google</span>
        </h1>
        <p class="text-lg text-slate-500 leading-relaxed mb-8 max-w-lg">
          เราช่วยธุรกิจกว่า <strong class="text-slate-700">500+ ราย</strong> ครองอันดับ 1 บน Google ด้วยกลยุทธ์ SEO ที่วัดผลได้จริง อัตราความสำเร็จ <strong class="text-slate-700">97%</strong>
        </p>
        <div class="flex flex-col sm:flex-row gap-4 mb-12">
          <a href="<?php echo get_permalink(get_page_by_path('contact')); ?>" class="inline-flex items-center justify-center gap-2 px-8 py-4 bg-gradient-to-r from-gold-500 to-gold-600 hover:from-gold-600 hover:to-gold-700 text-white font-bold rounded-2xl text-base transition-all hover:shadow-xl hover:shadow-gold-500/30 hover:-translate-y-1">
            <i class="fas fa-star text-gold-200"></i>ขอคำปรึกษาฟรี
          </a>
          <a href="<?php echo get_post_type_archive_link('portfolio'); ?>" class="inline-flex items-center justify-center gap-2 px-8 py-4 bg-white border-2 border-slate-200 text-slate-700 font-semibold rounded-2xl text-base hover:border-primary-300 hover:text-primary-700 transition-all hover:-translate-y-1">
            <i class="fas fa-chart-line text-primary-400"></i>ดูผลงาน
          </a>
        </div>
        <div class="flex flex-wrap gap-x-8 gap-y-4">
          <?php
          $stats = [
            ['500+', 'ลูกค้า'],
            ['97%', 'Success Rate'],
            ['8', 'ปีประสบการณ์'],
          ];
          foreach ($stats as $s): ?>
          <div class="flex items-center gap-2">
            <span class="text-2xl font-bold gradient-text"><?php echo $s[0]; ?></span>
            <span class="text-sm text-slate-500"><?php echo $s[1]; ?></span>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
      <!-- Floating Stats Card -->
      <div class="reveal reveal-delay-2 hidden lg:block relative">
        <div class="glass-card rounded-3xl p-8">
          <div class="grid grid-cols-2 gap-4">
            <?php
            $cards = [
              ['fas fa-chart-bar', 'primary', 'Organic Traffic', '+285%', 'avg. increase'],
              ['fas fa-trophy', 'gold', 'Top Rankings', '97%', 'within 6 months'],
              ['fas fa-link', 'emerald', 'Quality Links', '1,200+', 'built monthly'],
              ['fas fa-users', 'primary', 'Clients Served', '500+', 'satisfied clients'],
            ];
            foreach ($cards as $c): ?>
            <div class="luxury-card glass-card rounded-2xl p-5">
              <div class="w-10 h-10 rounded-xl bg-<?php echo $c[1]; ?>-100 flex items-center justify-center mb-3">
                <i class="<?php echo $c[0]; ?> text-<?php echo $c[1]; ?>-600 text-sm"></i>
              </div>
              <p class="text-xs text-slate-500 mb-1"><?php echo $c[1]; ?></p>
              <p class="text-xl font-bold text-slate-800"><?php echo $c[2]; ?></p>
              <p class="text-xs text-slate-400"><?php echo $c[3]; ?></p>
            </div>
            <?php endforeach; ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Services Preview -->
<section class="py-24 bg-white">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="text-center mb-14 reveal">
      <span class="inline-flex items-center gap-2 px-4 py-1.5 luxury-badge rounded-full text-xs font-semibold text-primary-700 mb-4">
        <i class="fas fa-cogs text-gold-500"></i>บริการของเรา
      </span>
      <h2 class="text-3xl lg:text-5xl font-bold text-slate-900 mb-4">ครอบคลุมทุก<span class="font-display italic gradient-text"> มิติ SEO</span></h2>
      <div class="gold-divider"></div>
    </div>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
      <?php
      $services = new WP_Query(['post_type' => 'service', 'posts_per_page' => 6, 'orderby' => 'menu_order', 'order' => 'ASC']);
      if ($services->have_posts()):
        while ($services->have_posts()): $services->the_post(); ?>
        <div class="luxury-card glass-card rounded-2xl p-7 reveal">
          <div class="w-12 h-12 rounded-xl bg-gradient-to-br from-primary-500 to-primary-700 flex items-center justify-center text-white text-lg mb-5 shadow-lg shadow-primary-500/25">
            <i class="fas fa-cog"></i>
          </div>
          <h3 class="font-bold text-slate-900 mb-2"><?php the_title(); ?></h3>
          <p class="text-slate-500 text-sm leading-relaxed"><?php the_excerpt(); ?></p>
          <a href="<?php the_permalink(); ?>" class="mt-4 inline-flex items-center gap-1 text-primary-600 text-sm font-semibold hover:gap-2 transition-all">อ่านเพิ่มเติม <i class="fas fa-arrow-right text-xs"></i></a>
        </div>
        <?php endwhile; wp_reset_postdata();
      else: ?>
        <div class="col-span-3 text-center text-slate-400 py-8">ยังไม่มีบริการ — เพิ่มบริการใน WordPress Admin → Services</div>
      <?php endif; ?>
    </div>
    <div class="text-center mt-10">
      <a href="<?php echo get_post_type_archive_link('service'); ?>" class="inline-flex items-center gap-2 px-7 py-3.5 border-2 border-primary-200 text-primary-700 font-semibold rounded-2xl hover:bg-primary-50 transition-all text-sm">
        ดูบริการทั้งหมด <i class="fas fa-arrow-right text-xs"></i>
      </a>
    </div>
  </div>
</section>

<!-- Latest Blog Posts -->
<section class="py-24 bg-slate-50">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="text-center mb-14 reveal">
      <span class="inline-flex items-center gap-2 px-4 py-1.5 luxury-badge rounded-full text-xs font-semibold text-primary-700 mb-4">
        <i class="fas fa-newspaper text-gold-500"></i>บทความล่าสุด
      </span>
      <h2 class="text-3xl lg:text-5xl font-bold text-slate-900 mb-4">ความรู้<span class="font-display italic gradient-text"> SEO</span></h2>
      <div class="gold-divider"></div>
    </div>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
      <?php
      $posts = new WP_Query(['post_type' => 'post', 'posts_per_page' => 3]);
      if ($posts->have_posts()):
        while ($posts->have_posts()): $posts->the_post(); ?>
        <article class="blog-card luxury-card glass-card rounded-2xl overflow-hidden reveal">
          <?php if (has_post_thumbnail()): ?>
          <div class="overflow-hidden h-48">
            <?php the_post_thumbnail('blog-thumb', ['class' => 'blog-image w-full h-full object-cover']); ?>
          </div>
          <?php endif; ?>
          <div class="p-6">
            <p class="text-xs text-primary-500 font-semibold mb-2"><?php echo get_the_date('d M Y'); ?></p>
            <h3 class="font-bold text-slate-900 mb-2 line-clamp-2"><?php the_title(); ?></h3>
            <p class="text-slate-500 text-sm mb-4 line-clamp-2"><?php the_excerpt(); ?></p>
            <a href="<?php the_permalink(); ?>" class="inline-flex items-center gap-1 text-primary-600 text-sm font-semibold hover:gap-2 transition-all">อ่านต่อ <i class="fas fa-arrow-right text-xs"></i></a>
          </div>
        </article>
        <?php endwhile; wp_reset_postdata();
      else: ?>
        <div class="col-span-3 text-center text-slate-400 py-8">ยังไม่มีบทความ — เพิ่มบทความใน WordPress Admin → Posts</div>
      <?php endif; ?>
    </div>
  </div>
</section>

<!-- CTA Section -->
<section class="cta-section py-24 text-white">
  <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
    <div class="reveal">
      <span class="inline-flex items-center gap-2 px-4 py-1.5 bg-white/10 border border-white/20 rounded-full text-sm font-semibold mb-6 backdrop-blur-sm">
        <i class="fas fa-rocket text-gold-400"></i>เริ่มต้นวันนี้
      </span>
      <h2 class="text-4xl lg:text-5xl font-bold mb-5 leading-tight">พร้อมพาธุรกิจคุณ<br><span class="font-display italic text-gold-400">สู่อันดับ 1</span> แล้วหรือยัง?</h2>
      <p class="text-white/70 mb-8 max-w-xl mx-auto">ขอรับคำปรึกษาฟรีพร้อม SEO Audit มูลค่า 3,500 บาท ไม่มีข้อผูกมัด</p>
      <div class="flex flex-col sm:flex-row gap-4 justify-center">
        <a href="<?php echo get_permalink(get_page_by_path('contact')); ?>" class="inline-flex items-center justify-center gap-2 px-8 py-4 bg-gradient-to-r from-gold-500 to-gold-600 hover:from-gold-600 hover:to-gold-700 text-white font-bold rounded-2xl transition-all hover:shadow-xl hover:shadow-gold-500/30 hover:-translate-y-1">
          <i class="fas fa-paper-plane"></i>ขอคำปรึกษาฟรี
        </a>
        <a href="<?php echo get_post_type_archive_link('portfolio'); ?>" class="inline-flex items-center justify-center gap-2 px-8 py-4 border-2 border-white/30 hover:border-white/60 text-white font-semibold rounded-2xl transition-all hover:-translate-y-1">
          <i class="fas fa-chart-bar"></i>ดูผลงาน
        </a>
      </div>
    </div>
  </div>
</section>

<?php get_footer(); ?>
