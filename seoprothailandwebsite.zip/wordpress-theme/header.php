<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?php wp_head(); ?>
</head>
<body <?php body_class('bg-white text-slate-800 antialiased'); ?>>
<?php wp_body_open(); ?>

<!-- Mobile Overlay -->
<div id="mobileOverlay" class="mobile-overlay fixed inset-0 bg-black/60 backdrop-blur-sm z-40 lg:hidden" onclick="closeMobileMenu()"></div>

<!-- Mobile Menu -->
<div id="mobileMenu" class="mobile-menu fixed top-0 right-0 w-80 h-full bg-white z-50 shadow-2xl lg:hidden overflow-y-auto">
  <div class="p-6">
    <div class="flex items-center justify-between mb-8">
      <span class="text-xl font-bold gradient-text">SEO PRO</span>
      <button onclick="closeMobileMenu()" class="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center hover:bg-slate-200 transition-colors">
        <i class="fas fa-times text-slate-600"></i>
      </button>
    </div>
    <nav class="space-y-1">
      <a href="<?php echo get_post_type_archive_link('service'); ?>" class="flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-primary-50 hover:text-primary-700 transition-colors font-medium text-sm"><i class="fas fa-cogs w-5 text-primary-400 text-xs"></i>บริการ</a>
      <a href="<?php echo get_post_type_archive_link('portfolio'); ?>" class="flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-primary-50 hover:text-primary-700 transition-colors font-medium text-sm"><i class="fas fa-chart-line w-5 text-primary-400 text-xs"></i>ผลงาน</a>
      <a href="<?php echo get_permalink(get_page_by_path('pricing')); ?>" class="flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-primary-50 hover:text-primary-700 transition-colors font-medium text-sm"><i class="fas fa-tags w-5 text-primary-400 text-xs"></i>ราคา</a>
      <a href="<?php echo get_permalink(get_page_by_path('blog')); ?>" class="flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-primary-50 hover:text-primary-700 transition-colors font-medium text-sm"><i class="fas fa-newspaper w-5 text-primary-400 text-xs"></i>บทความ</a>
      <a href="<?php echo get_permalink(get_page_by_path('faq')); ?>" class="flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-primary-50 hover:text-primary-700 transition-colors font-medium text-sm"><i class="fas fa-question-circle w-5 text-primary-400 text-xs"></i>FAQ</a>
      <a href="<?php echo get_permalink(get_page_by_path('contact')); ?>" class="flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-primary-50 hover:text-primary-700 transition-colors font-medium text-sm"><i class="fas fa-envelope w-5 text-primary-400 text-xs"></i>ติดต่อ</a>
    </nav>
    <a href="<?php echo get_permalink(get_page_by_path('contact')); ?>" class="mt-6 block w-full text-center py-3.5 bg-gradient-to-r from-gold-500 to-gold-600 text-white font-semibold rounded-2xl shadow-lg shadow-gold-500/25 text-sm">ขอคำปรึกษาฟรี</a>
  </div>
</div>

<div id="toastContainer" class="fixed top-24 right-6 z-50 space-y-3"></div>

<!-- Header -->
<header id="mainHeader" class="fixed top-0 left-0 w-full z-30 bg-white/92 backdrop-blur-xl border-b border-slate-100 transition-all duration-300">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="flex items-center justify-between h-16 lg:h-20">
      <a href="<?php echo home_url('/'); ?>" class="flex items-center gap-3 group">
        <?php if (has_custom_logo()): the_custom_logo(); else: ?>
        <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-primary-600 to-primary-800 flex items-center justify-center text-white text-lg font-bold shadow-lg shadow-primary-500/30 group-hover:shadow-primary-500/50 transition-all">S</div>
        <div>
          <div class="text-xl font-bold tracking-tight gradient-text leading-none">SEO PRO</div>
          <div class="text-[10px] tracking-[0.2em] font-semibold text-slate-400 uppercase">Thailand</div>
        </div>
        <?php endif; ?>
      </a>
      <nav class="hidden lg:flex items-center gap-1">
        <a href="<?php echo get_post_type_archive_link('service'); ?>" class="px-3 py-2 text-sm font-medium text-slate-600 hover:text-primary-600 rounded-lg hover:bg-primary-50 transition-all <?php echo (is_post_type_archive('service') || is_singular('service')) ? 'text-primary-600 bg-primary-50' : ''; ?>">บริการ</a>
        <a href="<?php echo get_post_type_archive_link('portfolio'); ?>" class="px-3 py-2 text-sm font-medium text-slate-600 hover:text-primary-600 rounded-lg hover:bg-primary-50 transition-all <?php echo (is_post_type_archive('portfolio') || is_singular('portfolio')) ? 'text-primary-600 bg-primary-50' : ''; ?>">ผลงาน</a>
        <a href="<?php echo get_permalink(get_page_by_path('pricing')); ?>" class="px-3 py-2 text-sm font-medium text-slate-600 hover:text-primary-600 rounded-lg hover:bg-primary-50 transition-all <?php echo is_page('pricing') ? 'text-primary-600 bg-primary-50' : ''; ?>">ราคา</a>
        <a href="<?php echo get_permalink(get_page_by_path('blog')); ?>" class="px-3 py-2 text-sm font-medium text-slate-600 hover:text-primary-600 rounded-lg hover:bg-primary-50 transition-all <?php echo (is_home() || is_singular('post') || is_category()) ? 'text-primary-600 bg-primary-50' : ''; ?>">บทความ</a>
        <a href="<?php echo get_permalink(get_page_by_path('faq')); ?>" class="px-3 py-2 text-sm font-medium text-slate-600 hover:text-primary-600 rounded-lg hover:bg-primary-50 transition-all <?php echo is_page('faq') ? 'text-primary-600 bg-primary-50' : ''; ?>">FAQ</a>
      </nav>
      <div class="flex items-center gap-3">
        <a href="<?php echo get_permalink(get_page_by_path('contact')); ?>" class="hidden sm:inline-flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-gold-500 to-gold-600 hover:from-gold-600 hover:to-gold-700 text-white text-sm font-semibold rounded-xl transition-all hover:shadow-lg hover:shadow-gold-500/30 hover:-translate-y-0.5">
          <i class="fas fa-star text-gold-200 text-xs"></i>ขอคำปรึกษาฟรี
        </a>
        <button onclick="openMobileMenu()" class="lg:hidden w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center hover:bg-slate-200 transition-colors">
          <i class="fas fa-bars text-slate-600"></i>
        </button>
      </div>
    </div>
  </div>
</header>
