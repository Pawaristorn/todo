<?php get_header(); ?>

<section class="page-hero pt-36 pb-20 lg:pt-44 lg:pb-28 text-white relative z-10">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
    <div class="reveal">
      <span class="inline-flex items-center gap-2 px-4 py-1.5 bg-white/10 border border-white/20 rounded-full text-sm font-semibold mb-6 backdrop-blur-sm">
        <i class="fas fa-trophy text-gold-400 text-xs"></i>ผลงาน
      </span>
      <h1 class="text-4xl lg:text-6xl font-bold mb-4 leading-tight">
        ผลงานที่<span class="font-display italic text-gold-400"> พิสูจน์แล้ว</span>
      </h1>
      <p class="text-lg text-white/75 max-w-2xl mx-auto">Case studies จริงที่แสดงให้เห็นถึงผลลัพธ์ที่วัดได้</p>
    </div>
  </div>
</section>

<section class="py-20 bg-white">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <?php if (have_posts()): ?>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      <?php while (have_posts()): the_post(); ?>
      <article <?php post_class('luxury-card glass-card rounded-2xl overflow-hidden reveal'); ?>>
        <?php if (has_post_thumbnail()): ?>
        <div class="overflow-hidden h-48">
          <?php the_post_thumbnail('portfolio-thumb', ['class' => 'blog-image w-full h-full object-cover']); ?>
        </div>
        <?php endif; ?>
        <div class="p-6">
          <div class="flex items-center gap-2 mb-2">
            <?php the_terms(get_the_ID(), 'portfolio_category', '<span class="text-xs font-semibold text-primary-600 luxury-badge px-3 py-1 rounded-full">', ', ', '</span>'); ?>
          </div>
          <h2 class="font-bold text-slate-900 mb-2"><a href="<?php the_permalink(); ?>" class="hover:text-primary-600 transition-colors"><?php the_title(); ?></a></h2>
          <p class="text-slate-500 text-sm mb-4 line-clamp-2"><?php the_excerpt(); ?></p>
          <div class="grid grid-cols-3 gap-3 mb-4">
            <?php
            $metrics = [
              ['meta_key' => 'traffic_increase', 'label' => 'Traffic'],
              ['meta_key' => 'keywords_ranked',  'label' => 'Keywords'],
              ['meta_key' => 'ranking_time',     'label' => 'ระยะเวลา'],
            ];
            foreach ($metrics as $m):
              $val = get_post_meta(get_the_ID(), $m['meta_key'], true);
              if ($val): ?>
            <div class="text-center p-2 bg-primary-50 rounded-xl">
              <p class="font-bold text-primary-700 text-sm"><?php echo esc_html($val); ?></p>
              <p class="text-xs text-slate-500"><?php echo $m['label']; ?></p>
            </div>
            <?php endif; endforeach; ?>
          </div>
          <a href="<?php the_permalink(); ?>" class="inline-flex items-center gap-1 text-primary-600 text-sm font-semibold hover:gap-2 transition-all">ดูรายละเอียด <i class="fas fa-arrow-right text-xs"></i></a>
        </div>
      </article>
      <?php endwhile; ?>
    </div>
    <div class="mt-10 text-center">
      <?php the_posts_pagination(['mid_size' => 2]); ?>
    </div>
    <?php else: ?>
    <div class="text-center py-16 text-slate-400">
      <i class="fas fa-trophy text-4xl mb-4 opacity-30"></i>
      <p>ยังไม่มีผลงาน — เพิ่มผลงานใน WordPress Admin → Portfolio</p>
    </div>
    <?php endif; ?>
  </div>
</section>

<!-- CTA -->
<section class="cta-section py-20 text-white">
  <div class="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center reveal">
    <h2 class="text-3xl lg:text-4xl font-bold mb-4">พร้อมเป็นผลงานถัดไปของเรา?</h2>
    <p class="text-white/70 mb-7">ขอรับคำปรึกษาฟรีและดูว่าเราจะช่วยธุรกิจคุณได้อย่างไร</p>
    <a href="<?php echo get_permalink(get_page_by_path('contact')); ?>" class="inline-flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-gold-500 to-gold-600 text-white font-bold rounded-2xl hover:shadow-xl hover:shadow-gold-500/30 hover:-translate-y-1 transition-all">
      <i class="fas fa-paper-plane"></i>ขอคำปรึกษาฟรี
    </a>
  </div>
</section>

<?php get_footer(); ?>
