<?php get_header(); ?>

<section class="page-hero pt-36 pb-20 lg:pt-44 lg:pb-28 text-white relative z-10">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
    <div class="reveal">
      <h1 class="text-4xl lg:text-6xl font-bold mb-4">
        <?php
        if (is_home()) echo 'บทความ <span class="font-display italic text-gold-400">SEO</span>';
        elseif (is_category()) echo 'หมวดหมู่: <span class="font-display italic text-gold-400">' . single_cat_title('', false) . '</span>';
        elseif (is_tag()) echo 'แท็ก: <span class="font-display italic text-gold-400">' . single_tag_title('', false) . '</span>';
        elseif (is_search()) echo 'ผลการค้นหา: <span class="font-display italic text-gold-400">' . get_search_query() . '</span>';
        else the_title();
        ?>
      </h1>
    </div>
  </div>
</section>

<section class="py-20 bg-white">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
      <div class="lg:col-span-2">
        <?php if (have_posts()): ?>
          <div class="space-y-6">
          <?php while (have_posts()): the_post(); ?>
            <article <?php post_class('blog-card luxury-card glass-card rounded-2xl overflow-hidden'); ?>>
              <?php if (has_post_thumbnail()): ?>
              <div class="overflow-hidden h-56">
                <?php the_post_thumbnail('blog-thumb', ['class' => 'blog-image w-full h-full object-cover']); ?>
              </div>
              <?php endif; ?>
              <div class="p-7">
                <div class="flex items-center gap-3 mb-3 text-xs text-slate-400">
                  <span><?php echo get_the_date('d M Y'); ?></span>
                  <span>•</span>
                  <span><?php the_category(', '); ?></span>
                </div>
                <h2 class="text-xl font-bold text-slate-900 mb-3"><a href="<?php the_permalink(); ?>" class="hover:text-primary-600 transition-colors"><?php the_title(); ?></a></h2>
                <p class="text-slate-500 text-sm mb-4"><?php the_excerpt(); ?></p>
                <a href="<?php the_permalink(); ?>" class="inline-flex items-center gap-1 text-primary-600 text-sm font-semibold hover:gap-2 transition-all">อ่านต่อ <i class="fas fa-arrow-right text-xs"></i></a>
              </div>
            </article>
          <?php endwhile; ?>
          </div>
          <div class="mt-8">
            <?php the_posts_pagination(['mid_size' => 2, 'prev_text' => '<i class="fas fa-chevron-left"></i>', 'next_text' => '<i class="fas fa-chevron-right"></i>']); ?>
          </div>
        <?php else: ?>
          <div class="glass-card rounded-2xl p-12 text-center text-slate-400">
            <i class="fas fa-newspaper text-4xl mb-4 opacity-30"></i>
            <p>ยังไม่มีบทความ</p>
          </div>
        <?php endif; ?>
      </div>

      <!-- Sidebar -->
      <aside class="space-y-6">
        <div class="glass-card rounded-2xl p-6">
          <h3 class="font-bold text-slate-900 mb-4">ค้นหา</h3>
          <?php get_search_form(); ?>
        </div>
        <div class="glass-card rounded-2xl p-6">
          <h3 class="font-bold text-slate-900 mb-4">หมวดหมู่</h3>
          <ul class="space-y-2 text-sm text-slate-600">
            <?php wp_list_categories(['show_count' => true, 'title_li' => '', 'walker' => null]); ?>
          </ul>
        </div>
        <div class="glass-card rounded-2xl p-6">
          <h3 class="font-bold text-slate-900 mb-4">บทความล่าสุด</h3>
          <?php
          $recent = new WP_Query(['posts_per_page' => 5]);
          while ($recent->have_posts()): $recent->the_post(); ?>
          <a href="<?php the_permalink(); ?>" class="flex items-start gap-3 py-2 border-b border-slate-100 last:border-0 hover:text-primary-600 transition-colors">
            <?php if (has_post_thumbnail()): ?>
            <div class="w-14 h-14 rounded-xl overflow-hidden flex-shrink-0"><?php the_post_thumbnail('thumbnail', ['class' => 'w-full h-full object-cover']); ?></div>
            <?php endif; ?>
            <div><p class="text-sm font-medium leading-tight"><?php the_title(); ?></p><p class="text-xs text-slate-400 mt-1"><?php echo get_the_date('d M Y'); ?></p></div>
          </a>
          <?php endwhile; wp_reset_postdata(); ?>
        </div>
        <div class="cta-section rounded-2xl p-6 text-white text-center">
          <i class="fas fa-rocket text-gold-400 text-2xl mb-3"></i>
          <h3 class="font-bold mb-2">ขอคำปรึกษาฟรี</h3>
          <p class="text-white/70 text-xs mb-4">ประเมินเว็บไซต์ฟรี ไม่มีข้อผูกมัด</p>
          <a href="<?php echo get_permalink(get_page_by_path('contact')); ?>" class="block py-2.5 bg-gradient-to-r from-gold-500 to-gold-600 text-white font-semibold rounded-xl text-sm">ติดต่อเรา</a>
        </div>
      </aside>
    </div>
  </div>
</section>

<?php get_footer(); ?>
