<?php get_header(); ?>

<section class="min-h-screen flex items-center justify-center bg-white pt-20">
  <div class="max-w-lg mx-auto px-4 text-center reveal">
    <div class="text-[10rem] font-display font-bold gradient-text leading-none mb-4">404</div>
    <h1 class="text-2xl font-bold text-slate-900 mb-3">ไม่พบหน้าที่คุณค้นหา</h1>
    <p class="text-slate-500 mb-8">หน้าที่คุณต้องการอาจถูกย้าย ลบ หรือ URL ไม่ถูกต้อง</p>
    <div class="flex flex-col sm:flex-row gap-3 justify-center">
      <a href="<?php echo home_url('/'); ?>" class="inline-flex items-center justify-center gap-2 px-7 py-3.5 bg-gradient-to-r from-primary-600 to-primary-700 text-white font-semibold rounded-2xl hover:shadow-lg hover:-translate-y-0.5 transition-all text-sm">
        <i class="fas fa-home"></i>กลับหน้าแรก
      </a>
      <a href="<?php echo get_permalink(get_page_by_path('contact')); ?>" class="inline-flex items-center justify-center gap-2 px-7 py-3.5 border-2 border-primary-200 text-primary-700 font-semibold rounded-2xl hover:bg-primary-50 transition-all text-sm">
        <i class="fas fa-envelope"></i>ติดต่อเรา
      </a>
    </div>
  </div>
</section>

<?php get_footer(); ?>
