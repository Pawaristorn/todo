<footer class="bg-slate-900 text-white pt-16 pb-8">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="grid grid-cols-1 md:grid-cols-4 gap-10 mb-12">
      <div class="md:col-span-2">
        <div class="flex items-center gap-3 mb-5">
          <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-primary-500 to-primary-700 flex items-center justify-center text-white font-bold text-lg">S</div>
          <div>
            <div class="text-lg font-bold gradient-text">SEO PRO</div>
            <div class="text-[10px] tracking-widest text-slate-400 uppercase">Thailand</div>
          </div>
        </div>
        <p class="text-slate-400 text-sm leading-relaxed max-w-xs mb-5">บริษัท SEO ชั้นนำของไทย ที่ช่วยธุรกิจของคุณครองอันดับ 1 บน Google ด้วยกลยุทธ์ที่พิสูจน์แล้วกับลูกค้ากว่า 500 ราย</p>
        <div class="flex items-center gap-3">
          <a href="https://www.facebook.com/seoprothailand" class="w-9 h-9 rounded-xl bg-white/10 hover:bg-primary-600 flex items-center justify-center text-white transition-all" aria-label="Facebook"><i class="fab fa-facebook-f text-sm"></i></a>
          <a href="https://line.me/R/ti/p/@seoprothailand" class="w-9 h-9 rounded-xl bg-white/10 hover:bg-emerald-500 flex items-center justify-center text-white transition-all" aria-label="LINE"><i class="fab fa-line text-sm"></i></a>
          <a href="https://www.youtube.com/@seoprothailand" class="w-9 h-9 rounded-xl bg-white/10 hover:bg-red-600 flex items-center justify-center text-white transition-all" aria-label="YouTube"><i class="fab fa-youtube text-sm"></i></a>
        </div>
      </div>
      <div>
        <h4 class="font-semibold text-white mb-4 text-sm uppercase tracking-wider">บริการ</h4>
        <ul class="space-y-2 text-sm text-slate-400">
          <li><a href="<?php echo get_post_type_archive_link('service'); ?>" class="hover:text-gold-400 transition-colors">SEO On-Page</a></li>
          <li><a href="<?php echo get_post_type_archive_link('service'); ?>" class="hover:text-gold-400 transition-colors">SEO Off-Page</a></li>
          <li><a href="<?php echo get_post_type_archive_link('service'); ?>" class="hover:text-gold-400 transition-colors">Technical SEO</a></li>
          <li><a href="<?php echo get_post_type_archive_link('service'); ?>" class="hover:text-gold-400 transition-colors">Local SEO</a></li>
          <li><a href="<?php echo get_post_type_archive_link('service'); ?>" class="hover:text-gold-400 transition-colors">Content Marketing</a></li>
        </ul>
      </div>
      <div>
        <h4 class="font-semibold text-white mb-4 text-sm uppercase tracking-wider">ติดต่อ</h4>
        <ul class="space-y-3 text-sm text-slate-400">
          <li class="flex items-center gap-2"><i class="fas fa-phone text-gold-500 w-4"></i><a href="tel:+6620001234" class="hover:text-gold-400 transition-colors"><?php echo esc_html(seo_option('phone', '020-001-234')); ?></a></li>
          <li class="flex items-center gap-2"><i class="fas fa-envelope text-gold-500 w-4"></i><a href="mailto:hello@seoprothailand.com" class="hover:text-gold-400 transition-colors"><?php echo esc_html(seo_option('email', 'hello@seoprothailand.com')); ?></a></li>
          <li class="flex items-center gap-2"><i class="fab fa-line text-gold-500 w-4"></i><span><?php echo esc_html(seo_option('line_id', '@seoprothailand')); ?></span></li>
          <li class="flex items-start gap-2"><i class="fas fa-map-marker-alt text-gold-500 w-4 mt-0.5"></i><span><?php echo esc_html(seo_option('address', 'Empire Tower, Sathorn, Bangkok 10120')); ?></span></li>
        </ul>
      </div>
    </div>
    <div class="border-t border-slate-800 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4">
      <p class="text-slate-500 text-xs">© <?php echo date('Y'); ?> SEO PRO THAILAND. All rights reserved.</p>
      <div class="flex items-center gap-4">
        <a href="<?php echo get_privacy_policy_url(); ?>" class="text-slate-500 hover:text-gold-400 transition-colors text-sm">นโยบายความเป็นส่วนตัว</a>
        <a href="#" class="text-slate-500 hover:text-gold-400 transition-colors text-sm">ข้อกำหนดการใช้งาน</a>
      </div>
    </div>
  </div>
</footer>

<button onclick="scrollToTop()" id="backToTop" class="back-to-top fixed bottom-6 right-6 w-11 h-11 rounded-full bg-gradient-to-br from-primary-600 to-primary-800 text-white shadow-lg shadow-primary-500/30 flex items-center justify-center z-50 hover:shadow-primary-500/50 transition-all hover:-translate-y-0.5" aria-label="Back to top">
  <i class="fas fa-chevron-up text-sm"></i>
</button>

<?php wp_footer(); ?>
</body>
</html>
