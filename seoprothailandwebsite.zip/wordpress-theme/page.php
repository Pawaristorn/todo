<?php get_header(); ?>

<?php while (have_posts()): the_post(); ?>

<section class="page-hero pt-36 pb-16 lg:pt-44 lg:pb-20 text-white relative z-10">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
    <div class="reveal">
      <h1 class="text-4xl lg:text-6xl font-bold mb-4 leading-tight"><?php the_title(); ?></h1>
      <?php if (get_the_excerpt()): ?>
      <p class="text-lg text-white/75 max-w-2xl mx-auto"><?php the_excerpt(); ?></p>
      <?php endif; ?>
    </div>
  </div>
</section>

<section class="py-20 bg-white">
  <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="glass-card rounded-3xl p-8 lg:p-12">
      <div class="prose prose-slate prose-lg max-w-none">
        <?php the_content(); ?>
      </div>
    </div>
  </div>
</section>

<?php endwhile; ?>

<?php get_footer(); ?>
