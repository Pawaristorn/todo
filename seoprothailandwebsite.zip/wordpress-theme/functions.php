<?php
defined('ABSPATH') || exit;

// ── Theme Setup ───────────────────────────────────────────────
function seoprothailand_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', ['search-form', 'comment-form', 'comment-list', 'gallery', 'caption']);
    add_theme_support('custom-logo', ['height' => 60, 'width' => 200, 'flex-height' => true, 'flex-width' => true]);
    add_image_size('portfolio-thumb', 800, 500, true);
    add_image_size('blog-thumb', 600, 400, true);

    register_nav_menus([
        'primary' => __('Primary Menu', 'seoprothailand'),
        'footer'  => __('Footer Menu', 'seoprothailand'),
    ]);
}
add_action('after_setup_theme', 'seoprothailand_setup');

// ── Enqueue Assets ────────────────────────────────────────────
function seoprothailand_enqueue() {
    wp_enqueue_style('google-fonts', 'https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@500;600;700&family=Inter:wght@300;400;500;600;700;800&family=Noto+Sans+Thai:wght@300;400;500;600;700&display=swap', [], null);
    wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css', [], '6.5.0');
    wp_enqueue_style('seoprothailand-style', get_stylesheet_uri(), [], '1.0.0');
    wp_enqueue_script('tailwindcss', 'https://cdn.tailwindcss.com', [], null, false);
    wp_enqueue_script('seoprothailand-main', get_template_directory_uri() . '/assets/js/main.js', [], '1.0.0', true);

    // Pass AJAX URL to JS
    wp_localize_script('seoprothailand-main', 'seoAjax', [
        'url'   => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('seo_contact_nonce'),
    ]);
}
add_action('wp_enqueue_scripts', 'seoprothailand_enqueue');

// ── Tailwind Config inline in <head> ─────────────────────────
function seoprothailand_tailwind_config() {
    ?>
    <script>
    tailwind.config = {
        theme: { extend: {
            fontFamily: { sans:['Inter','Noto Sans Thai','system-ui','sans-serif'], display:['Cormorant Garamond','serif'] },
            colors: {
                primary:{ 50:'#eef2ff',100:'#e0e7ff',200:'#c7d2fe',300:'#a5b4fc',400:'#818cf8',500:'#6366f1',600:'#4f46e5',700:'#4338ca',800:'#3730a3',900:'#312e81' },
                gold:   { 50:'#fffbeb',100:'#fef3c7',200:'#fde68a',300:'#fcd34d',400:'#fbbf24',500:'#f59e0b',600:'#d97706',700:'#b45309',800:'#92400e',900:'#78350f' }
            }
        }}
    }
    </script>
    <?php
}
add_action('wp_head', 'seoprothailand_tailwind_config', 5);

// ── Custom Post Types ─────────────────────────────────────────
function seoprothailand_register_post_types() {
    // Portfolio / Case Studies
    register_post_type('portfolio', [
        'labels' => [
            'name'          => __('Portfolio', 'seoprothailand'),
            'singular_name' => __('Portfolio Item', 'seoprothailand'),
            'add_new_item'  => __('Add New Case Study', 'seoprothailand'),
            'edit_item'     => __('Edit Case Study', 'seoprothailand'),
        ],
        'public'        => true,
        'has_archive'   => true,
        'menu_icon'     => 'dashicons-chart-line',
        'supports'      => ['title', 'editor', 'thumbnail', 'excerpt', 'custom-fields'],
        'rewrite'       => ['slug' => 'portfolio'],
        'show_in_rest'  => true,
    ]);

    // Services
    register_post_type('service', [
        'labels' => [
            'name'          => __('Services', 'seoprothailand'),
            'singular_name' => __('Service', 'seoprothailand'),
            'add_new_item'  => __('Add New Service', 'seoprothailand'),
        ],
        'public'        => true,
        'has_archive'   => false,
        'menu_icon'     => 'dashicons-admin-settings',
        'supports'      => ['title', 'editor', 'thumbnail', 'excerpt'],
        'rewrite'       => ['slug' => 'services'],
        'show_in_rest'  => true,
    ]);

    // Testimonials
    register_post_type('testimonial', [
        'labels' => [
            'name'          => __('Testimonials', 'seoprothailand'),
            'singular_name' => __('Testimonial', 'seoprothailand'),
            'add_new_item'  => __('Add New Testimonial', 'seoprothailand'),
        ],
        'public'        => false,
        'show_ui'       => true,
        'menu_icon'     => 'dashicons-format-quote',
        'supports'      => ['title', 'editor', 'thumbnail'],
        'show_in_rest'  => true,
    ]);
}
add_action('init', 'seoprothailand_register_post_types');

// ── Custom Taxonomies ─────────────────────────────────────────
function seoprothailand_register_taxonomies() {
    register_taxonomy('service_category', ['service'], [
        'labels'        => ['name' => __('Service Categories', 'seoprothailand'), 'singular_name' => __('Category', 'seoprothailand')],
        'hierarchical'  => true,
        'show_in_rest'  => true,
        'rewrite'       => ['slug' => 'service-category'],
    ]);

    register_taxonomy('portfolio_category', ['portfolio'], [
        'labels'        => ['name' => __('Portfolio Categories', 'seoprothailand'), 'singular_name' => __('Category', 'seoprothailand')],
        'hierarchical'  => true,
        'show_in_rest'  => true,
        'rewrite'       => ['slug' => 'portfolio-category'],
    ]);
}
add_action('init', 'seoprothailand_register_taxonomies');

// ── AJAX Contact Form Handler ─────────────────────────────────
function seoprothailand_handle_contact() {
    check_ajax_referer('seo_contact_nonce', 'nonce');

    $name    = sanitize_text_field($_POST['name'] ?? '');
    $phone   = sanitize_text_field($_POST['phone'] ?? '');
    $email   = sanitize_email($_POST['email'] ?? '');
    $package = sanitize_text_field($_POST['package'] ?? '');
    $website = esc_url_raw($_POST['website'] ?? '');
    $message = sanitize_textarea_field($_POST['message'] ?? '');

    if (empty($name) || empty($phone) || !is_email($email)) {
        wp_send_json_error(['message' => 'กรุณากรอกข้อมูลให้ครบถ้วน']);
    }

    $to      = get_option('admin_email');
    $subject = "คำปรึกษา SEO ใหม่จาก: {$name}";
    $body    = "ชื่อ: {$name}\nโทร: {$phone}\nอีเมล: {$email}\nแพ็กเกจ: {$package}\nเว็บไซต์: {$website}\n\nข้อความ:\n{$message}";
    $headers = ["Content-Type: text/plain; charset=UTF-8", "From: {$name} <{$email}>", "Reply-To: {$email}"];

    $sent = wp_mail($to, $subject, $body, $headers);

    if ($sent) {
        // Save submission as a post for record-keeping
        wp_insert_post([
            'post_type'   => 'contact_submission',
            'post_title'  => "{$name} — " . current_time('d/m/Y H:i'),
            'post_status' => 'private',
            'meta_input'  => compact('name', 'phone', 'email', 'package', 'website', 'message'),
        ]);
        wp_send_json_success(['message' => 'ส่งข้อมูลสำเร็จ ทีมงานจะติดต่อกลับภายใน 24 ชั่วโมง']);
    } else {
        wp_send_json_error(['message' => 'เกิดข้อผิดพลาด กรุณาลองใหม่อีกครั้ง']);
    }
}
add_action('wp_ajax_seo_contact', 'seoprothailand_handle_contact');
add_action('wp_ajax_nopriv_seo_contact', 'seoprothailand_handle_contact');

// ── Schema.org JSON-LD ────────────────────────────────────────
function seoprothailand_schema_output() {
    $schema = [
        '@context' => 'https://schema.org',
        '@type'    => 'LocalBusiness',
        'name'     => 'SEO PRO THAILAND',
        'url'      => home_url('/'),
        'logo'     => get_template_directory_uri() . '/assets/images/logo.png',
        'description' => 'บริษัท SEO ชั้นนำของไทย ให้บริการ SEO On-Page, Off-Page, Technical SEO, Local SEO และ Content Marketing',
        'telephone' => '+6620001234',
        'email'    => 'hello@seoprothailand.com',
        'address'  => [
            '@type'           => 'PostalAddress',
            'streetAddress'   => 'Empire Tower, Sathorn',
            'addressLocality' => 'Bangkok',
            'postalCode'      => '10120',
            'addressCountry'  => 'TH',
        ],
        'geo' => ['@type' => 'GeoCoordinates', 'latitude' => '13.7563', 'longitude' => '100.5018'],
        'openingHoursSpecification' => [
            ['@type' => 'OpeningHoursSpecification', 'dayOfWeek' => ['Monday','Tuesday','Wednesday','Thursday','Friday'], 'opens' => '09:00', 'closes' => '18:00'],
            ['@type' => 'OpeningHoursSpecification', 'dayOfWeek' => ['Saturday'], 'opens' => '10:00', 'closes' => '16:00'],
        ],
        'sameAs' => ['https://www.facebook.com/seoprothailand', 'https://line.me/R/ti/p/@seoprothailand'],
        'priceRange' => '฿฿฿',
    ];
    echo '<script type="application/ld+json">' . wp_json_encode($schema, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) . '</script>' . "\n";
}
add_action('wp_head', 'seoprothailand_schema_output');

// ── Theme Options (Customizer) ────────────────────────────────
function seoprothailand_customizer($wp_customize) {
    $wp_customize->add_section('seoprothailand_options', [
        'title'    => __('SEO PRO Settings', 'seoprothailand'),
        'priority' => 200,
    ]);

    $fields = [
        'phone'   => ['label' => 'Phone Number', 'default' => '020-001-234'],
        'email'   => ['label' => 'Contact Email', 'default' => 'hello@seoprothailand.com'],
        'line_id' => ['label' => 'LINE ID', 'default' => '@seoprothailand'],
        'address' => ['label' => 'Address', 'default' => 'Empire Tower, Sathorn, Bangkok 10120'],
    ];

    foreach ($fields as $key => $opts) {
        $wp_customize->add_setting("seoprothailand_{$key}", ['default' => $opts['default'], 'sanitize_callback' => 'sanitize_text_field']);
        $wp_customize->add_control("seoprothailand_{$key}", ['label' => $opts['label'], 'section' => 'seoprothailand_options', 'type' => 'text']);
    }
}
add_action('customize_register', 'seoprothailand_customizer');

// ── Helper: Get Theme Option ──────────────────────────────────
function seo_option($key, $fallback = '') {
    return get_theme_mod("seoprothailand_{$key}", $fallback);
}

// ── Excerpt Length ────────────────────────────────────────────
add_filter('excerpt_length', fn() => 30);
add_filter('excerpt_more', fn() => '...');

// ── Remove Emoji Scripts ──────────────────────────────────────
remove_action('wp_head', 'print_emoji_detection_script', 7);
remove_action('wp_print_styles', 'print_emoji_styles');
