/* ═══════════════════════════════════════════════
   SEO PRO THAILAND — Shared JavaScript
   ═══════════════════════════════════════════════ */

// ── Mobile Menu ──────────────────────────────────
function openMobileMenu() {
  document.getElementById('mobileMenu').classList.add('open');
  document.getElementById('mobileOverlay').classList.add('open');
  document.body.style.overflow = 'hidden';
}
function closeMobileMenu() {
  document.getElementById('mobileMenu').classList.remove('open');
  document.getElementById('mobileOverlay').classList.remove('open');
  document.body.style.overflow = '';
}

// ── FAQ Toggle ───────────────────────────────────
function toggleFaq(element) {
  const allFaq = document.querySelectorAll('.faq-item');
  const isActive = element.classList.contains('active');
  allFaq.forEach(item => item.classList.remove('active'));
  if (!isActive) element.classList.add('active');
}

// ── Header Scroll Effect ─────────────────────────
(function () {
  const header = document.getElementById('mainHeader');
  if (!header) return;
  window.addEventListener('scroll', () => {
    const s = window.pageYOffset;
    header.classList.toggle('header-scrolled', s > 50);
    const btn = document.getElementById('backToTop');
    if (btn) btn.classList.toggle('visible', s > 500);
  }, { passive: true });
})();

function scrollToTop() { window.scrollTo({ top: 0, behavior: 'smooth' }); }

// ── Active Nav Highlight (inner pages) ───────────
(function () {
  const path = window.location.pathname.split('/').pop();
  document.querySelectorAll('a[data-page]').forEach(a => {
    if (a.dataset.page === path) a.classList.add('nav-active');
  });
})();

// ── Scroll Reveal ────────────────────────────────
(function () {
  const els = document.querySelectorAll('.reveal');
  const obs = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) { e.target.classList.add('visible'); obs.unobserve(e.target); }
    });
  }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });
  els.forEach(el => obs.observe(el));
})();

// ── Counter Animation ────────────────────────────
(function () {
  const counters = document.querySelectorAll('[data-counter]');
  const obs = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (!e.isIntersecting) return;
      const t = e.target;
      const countTo = parseFloat(t.dataset.counter);
      const dec = parseInt(t.dataset.decimal || '0');
      const dur = 2000;
      const start = performance.now();
      (function tick(now) {
        const p = Math.min((now - start) / dur, 1);
        const ease = 1 - Math.pow(1 - p, 3);
        t.textContent = (countTo * ease).toFixed(dec);
        if (p < 1) requestAnimationFrame(tick);
      })(start);
      obs.unobserve(t);
    });
  }, { threshold: 0.5 });
  counters.forEach(c => obs.observe(c));
})();

// ── Form Handling ────────────────────────────────
function handleSubmit(event) {
  event.preventDefault();
  const form = document.getElementById('contactForm');
  const submitBtn = document.getElementById('submitBtn');
  const successMessage = document.getElementById('successMessage');

  let isValid = true;
  form.querySelectorAll('[required]').forEach(field => {
    const err = field.parentElement.querySelector('.error-message');
    const empty = field.type === 'checkbox' ? !field.checked : !field.value.trim();
    field.classList.toggle('error', empty);
    if (err) err.classList.toggle('hidden', !empty);
    if (empty) isValid = false;
  });

  const emailField = form.querySelector('[name="email"]');
  if (emailField && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailField.value)) {
    emailField.classList.add('error');
    isValid = false;
  }

  if (!isValid) return;

  submitBtn.disabled = true;
  submitBtn.innerHTML = '<div class="spinner"></div><span>กำลังส่ง...</span>';

  setTimeout(() => {
    form.classList.add('hidden');
    successMessage.classList.remove('hidden');
    showToast('ส่งข้อมูลสำเร็จ! ทีมงานจะติดต่อกลับภายใน 24 ชั่วโมง', 'success');
  }, 1500);
}

function resetForm() {
  const form = document.getElementById('contactForm');
  form.reset();
  form.classList.remove('hidden');
  document.getElementById('successMessage').classList.add('hidden');
  const btn = document.getElementById('submitBtn');
  btn.disabled = false;
  btn.innerHTML = '<span>ส่งข้อมูลขอรับคำปรึกษา</span><i class="fas fa-paper-plane ml-2"></i>';
}

// ── Toast ────────────────────────────────────────
function showToast(message, type = 'success') {
  const container = document.getElementById('toastContainer');
  if (!container) return;
  const colors = { success: 'bg-emerald-500', error: 'bg-red-500', info: 'bg-primary-500' };
  const icons  = { success: 'fa-check-circle', error: 'fa-exclamation-circle', info: 'fa-info-circle' };
  const toast = document.createElement('div');
  toast.className = `toast ${colors[type]||colors.info} text-white px-5 py-3.5 rounded-2xl shadow-lg flex items-center gap-x-3 min-w-[280px]`;
  toast.innerHTML = `<i class="fas ${icons[type]||icons.info}"></i><span class="font-medium text-sm">${message}</span>`;
  container.appendChild(toast);
  requestAnimationFrame(() => toast.classList.add('show'));
  setTimeout(() => { toast.classList.remove('show'); setTimeout(() => toast.remove(), 400); }, 4000);
}

// ── Smooth Anchor Scroll ─────────────────────────
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', function (e) {
    const id = this.getAttribute('href');
    if (id === '#') return;
    const target = document.querySelector(id);
    if (target) { e.preventDefault(); target.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
  });
});

// ── Form Blur Validation ─────────────────────────
document.querySelectorAll('.form-input').forEach(input => {
  input.addEventListener('blur', function () {
    const err = this.parentElement.querySelector('.error-message');
    if (this.required && !this.value.trim()) {
      this.classList.add('error');
      if (err) err.classList.remove('hidden');
    } else {
      this.classList.remove('error');
      if (err) err.classList.add('hidden');
    }
  });
  input.addEventListener('input', function () {
    if (this.value.trim()) {
      this.classList.remove('error');
      const err = this.parentElement.querySelector('.error-message');
      if (err) err.classList.add('hidden');
    }
  });
});
